import type { MetadataRoute } from "next";
export const dynamic = "force-static";
export default function sitemap(): MetadataRoute.Sitemap { const lastModified = new Date("2026-08-18"); return [{ url: "https://www.bauservice-rm.de", lastModified, changeFrequency: "monthly", priority: 1 }, { url: "https://www.bauservice-rm.de/impressum/", lastModified, changeFrequency: "yearly", priority: .2 }, { url: "https://www.bauservice-rm.de/datenschutz/", lastModified, changeFrequency: "yearly", priority: .2 }]; }
